const fs = require('fs');
const { parse, stringify } = require('csv/sync');
const readXlsxFile = require('read-excel-file/node');

// CONSTS
const SPLUNK_ID_COL = 2;
const SPLUNK_SERVICE_COL = 3;
const SPLUNK_CALLS_COL = 4;
const CRM_NAME_COL = 2;
const CRM_TYPE_COL = 3;
const CRM_ID_COL = 4;
const CRM_BU_COL = 5;
const CRM_CONSULTANT_COL = 12;

const SERVICES_LIST = [
  '<BuyerAdminDataGrpLinksReadServiceV1>',
  '<BuyerInsurabilityReadService-v1>',
  '<BuyerReferenceChangeServiceV1>',
  '<BuyerReviewDeclarationService-v1>',
  '<BuyerSubscriptionServiceV1>',
  '<BuyerSynthesisReadService-v1>',
  '<CalculatePremiumServiceV1>',
  '<CompanyInformationService-v1>',
  '<CompanyInformationService-v2>',
  '<CompanySearchServiceV7>',
  '<ConfidentialListIndicatorReadServiceV1>',
  '<ContactService-v2>',
  '<ContractPortfolioReadService-v1>',
  '<CountryGradeReadService-v1>',
  '<CreditLimitRequestServiceV4>',
  '<CreditLimitService-v1>',
  '<CustomerListRetrieveServiceV2>',
  '<DropDownDataServiceV1>',
  '<EHDocumentManagementService-v1>',
  '<EHFranceClaimsService-v1>',
  '<EHFranceCreditLimitAlertService-v1>',
  '<EventNotificationService-v1>',
  '<EventNotificationService-v2>',
  '<FirstEuroListRepertoireReadService-v1>',
  '<FirstEuroListRepertoireUpdateService-v1>',
  '<GradeInformationRequestServiceV2>',
  '<GradeOpinionReadService-v1>',
  '<GradeOpinionService-v1>',
  '<LimitDetailReadService-v2>',
  '<LimitDetailReadServiceV1>',
  '<ListBuyerRequestsReadService-v2>',
  '<ListBuyerRequestsReadServiceV1>',
  '<ListDetailBuyersReadServiceV1>',
  '<NewPolicyNumbersForQuotesServiceV1>',
  '<NonPaymentOverviewService-v1>',
  '<NoneBindingIndicationOfTermsServiceV1>',
  '<OnRiskTerminatedPoliciesServiceV1>',
  '<OverdueConsultationService-v1>',
  '<OverdueNotificationServiceV2>',
  '<OverdueNotificationServiceV3>',
  '<OverdueService-v1>',
  '<OverdueSubmitService-v1>',
  '<PolicyCreditInsuranceManageService-v1>',
  '<RequestService-v1>',
  '<RiskRatingReadServiceV2>',
];

// HERE ENTER THE DIFFERENT FILES YOU WANT TO COMPILE
const SPLUNK_FILES = [
  'Test_stat_Week-2022-05-09.csv',
  'Test_stat_Week-2022-05-16.csv',
  'Test_stat_Week-2022-05-23.csv',
  'Test_stat_Week-2022-05-30.csv',
];

const CRM_FILE = 'Allianz Trade API Sales+Projects.xlsx';

// TOOLING
const validateUID = (user) => {
  const UID = user[CRM_ID_COL];
  if (!UID) {
    return null;
  }
  if (/^\d+$/.test(UID.toString())) {
    return UID.toString();
  }
  return null;
};

(async () => {
  // STARTING
  console.log('working on the data, please wait...');

  // FIRST LOAD IN MEMORY THE CRM DATA
  let users = await readXlsxFile(`./input/${CRM_FILE}`);
  users = users.map((user) => ({
    UID: validateUID(user),
    name: user[CRM_NAME_COL],
    category: user[CRM_TYPE_COL],
    BU: user[CRM_BU_COL],
    consultant: user[CRM_CONSULTANT_COL],
  }));

  const parsed = SPLUNK_FILES.reduce((aggregate, file) => {
    const raw = fs.readFileSync(`./input/${file}`).toString();
    const parsed = parse(raw);
    parsed.shift(); // get rid of the first row (header)
    return [...aggregate, ...parsed];
  }, []);

  // MAPPER
  const mapped = parsed.map((row) => {
    row[SPLUNK_ID_COL] = row[SPLUNK_ID_COL].substring(
      1,
      row[SPLUNK_ID_COL].length - 1,
    );
    return row;
  });

  // COMPILATION (from [day, hour, UID, service, calls] to [UID, service, all_calls_combined])
  const compiled = mapped.reduce((aggregate, value) => {
    if (!aggregate[value[SPLUNK_ID_COL]]) {
      aggregate[value[SPLUNK_ID_COL]] = SERVICES_LIST.reduce(
        (object, service) => ({ ...object, [service]: 0 }),
        {},
      );
    }
    aggregate[value[SPLUNK_ID_COL]][value[SPLUNK_SERVICE_COL]] += parseInt(
      value[SPLUNK_CALLS_COL],
      10,
    );
    return aggregate;
  }, {});

  // SORT AND FORMAT
  const formatted = Object.entries(compiled)
    .sort(([indexA], [indexB]) => {
      if (indexA > indexB) {
        return 1;
      } else if (indexA < indexB) {
        return -1;
      } else {
        return 0;
      }
    })
    .map((row) => [row[0], ...Object.values(row[1])]);

  // ADD USER INFO FROM CRM
  const withUserInfo = formatted.map((row) => {
    const ifnot = (element) => element || 'MANUAL CHECK NEEDED';
    const user = users.find((user) => user.UID == row[0]);
    return [...row, ifnot(user?.name), ifnot(user?.category), ifnot(user?.BU), ifnot(user?.consultant)];
  });

  withUserInfo.unshift(['UID', ...SERVICES_LIST, 'Name', 'Category', 'BU', 'SmartLink Consultant']);

  // // STRINGIFICATION
  const stringified = stringify(withUserInfo);
  console.log(stringified);

  // NEW CSV CREATION
  fs.writeFileSync('./output/CompiledSmartLinkCalls.csv', stringified);
})();
