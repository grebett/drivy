const { Chance } = require('chance');
const { argv } = require('yargs');
const fs = require('fs');
const chance = new Chance();

const BUSINESS_UNIT_CODES = require('./data/businessUnits.json');
const COUNTRIES = require('./data/countries.json');
const LEGAL_FORMS_CODES = require('./data/legalFormsCodes.json');
const COMPANY_IDENTIFIERS = require('./data/companyIdentifiers.json');
const COVER_STATUS_CODES = [
  'AwaitingDecision',
  'AwaitingRecycling',
  'Rejected',
  'Cancelled',
  'AlreadyAgreed',
  'AdministrativeCancellation',
  'LimitUpdate',
  'AdministrativeWithdrawal',
  'FullCancellation',
  'PartialCancellation',
  'ContractualModification',
  'DiscretionaryLimit',
  'Maintain',
  'NonDenomme',
  'Refusal',
  'Agreement',
  'RestrictiveAnswer',
  'PartialWithdrawal',
  'UnableToCover',
  'SingleLimitWithdrawal',
  'CancelDueBuyerTransfert',
  'CancelDuePolicyTransfert',
  'RiskWithdrawal',
  'PolicyTransfer',
  'RollbackDuePolicyTransfert',
  'PolicyStatusChange',
  'BuyerTransfer',
  'LimitReactivation',
];

// CONSTS
const DAY = 1000 * 60 * 60 * 24;

// UTILS
const date = () => new Date(chance.date({ year: chance.pickone([2018, 2019, 2020]) })).toISOString().slice(0, 10);
const numberId = (number, min = 0) => chance.natural({ min, max: Math.pow(10, number) - 1 }).toString().padStart(number, '0');
const getCurrency = () => chance.pickone(['EUR', 'GBP', 'USD', 'CAD', 'CHF']);

const generateCoverSummary = (number) => {
  const currency = getCurrency();
  const requestDate = date();
  const decisionDate = new Date(Date.parse(requestDate) + (chance.natural({ min: 1, max: 10 }) * DAY)).toISOString().slice(0, 10);
  const requestedAmount = chance.natural({ min: 1000, max: 100000 });
  const coverStatusCode = chance.pickone(COVER_STATUS_CODES);
  const customerCompanyReference = `${chance.letter({ casing: 'upper' })}${chance.natural({ min: 100, max: 999 })}${chance.letter({ casing: 'upper' })}${chance.letter({ casing: 'upper' })}${chance.natural({ min: 100, max: 999 })}${chance.letter({ casing: 'upper' })}`;
  const businessUnitCode = chance.pickone(BUSINESS_UNIT_CODES).businessUnitCode;

  return new Array(number).fill(0).map(() => {
    return {
      coverId: `LIM${numberId(9)}`,
      coverStatusCode: coverStatusCode,
      coverTypeCode: 'CreditLimit',
      isStrategic: chance.bool(),
      coverLastUpdateDate: decisionDate,
      request: {
        coverRequestId: numberId(9),
        requestDate: requestDate,
        requestedAmount: requestedAmount,
        requestedCurrencyCode: currency,
        requestOrigin: 'MyEH',
        customerCompanyReference,
      },
      decision: {
        coverLimitId: numberId(9),
        decisionDate: decisionDate,
        permanent: {
          permanentAmount: requestedAmount,
          permanentStartDate: decisionDate,
        },
        currencyCode: currency,
        isCurrent: chance.bool(),
        hasConditions: chance.bool(),
        customerCompanyReference,
      },
      policy: {
        businessUnitCode,
        policyId: numberId(6),
        extensionId: numberId(3),
      },
      company: {
        companyId: numberId(6),
        companyName: chance.company(),
      },
    };
  });
};

const generateCompany = (number) => {
  const retryTillCorrectLegalFormCodes = (countryCode) => {
    let legalFormCode = null;
    for (let i = 0; i < LEGAL_FORMS_CODES.length; i++) {
      const pickedLegalFormCode = chance.pickone(LEGAL_FORMS_CODES);
      if (pickedLegalFormCode.countryCodes.findIndex((country) => country === countryCode) > -1) {
        legalFormCode = pickedLegalFormCode.legalFormCode;
        break;
      }
    }
    return legalFormCode || '';
  };

  const retryTillCorrectIdentifier = (countryCode) => {
    let companyIdentifier = null;
    for (let i = 0; i < COMPANY_IDENTIFIERS.length; i++) {
      const pickedCompanyIdenfier = chance.pickone(COMPANY_IDENTIFIERS);
      if (pickedCompanyIdenfier.countryCode === countryCode) {
        companyIdentifier = pickedCompanyIdenfier;
        break;
      }
    }
    return companyIdentifier || {
      companyIdentifierTypeCode: 'DUNS',
      maxLength: 9,
      minLength: 9,
    };
  };

  return new Array(number).fill(0).map(() => {
    const countryCode = chance.pickone(COUNTRIES).countryCode;
    const companyIdentifier = retryTillCorrectIdentifier(countryCode);
    return {
      companyId: numberId(6),
      companyName: chance.company().replace("'", "\\'"),
      companyAddress: chance.address(),
      countryCode,
      companyTypeCode: chance.pickone(['Company', 'Partnership', 'SoleTrader', 'PublicBody', 'Other', 'PrivateIndividual']),
      legalFormCode: retryTillCorrectLegalFormCodes(countryCode),
      companyIdentifierType: companyIdentifier.companyIdentifierTypeCode,
      companyIdentifierValue: numberId(companyIdentifier.maxLength, companyIdentifier.minLength - 1),
      communicationChannelType: 'PHONE_NUMBER',
      communicationChannelValue: countryCode === 'FR' ? chance.phone({ country: 'fr' }) : chance.phone({ country: 'us' }),
      grade: chance.pickone([
        '01 Exceptional',
        '02 Strong',
        '03 Good',
        '04 Above Average',
        '05 Average',
        '06 Below Average',
        '07 Weak',
        '08 Distressed',
        '09 Uninsurable',
        '10 Failed',
      ]),
    };
  });
};

// MAIN
(() => {
  const { t: type, n: number } = argv;
  const fns = {
    CoverSummary: generateCoverSummary,
    Company: generateCompany,
  };
  if (!type || !number) {
    console.error('Error: this program should be used as follow: ./binary -t [type] -n [number]');
    return;
  }
  if (isNaN(number) || number <= 0) {
    console.error('Error: -n argument should be a number > 0');
    return;
  }
  if (!fns[type]) {
    console.error(`Error: -t argument should one of the following values: ${Object.keys(fns).join(', ')}`);
    return;
  }
  const data = fns[type](number);
  fs.writeFileSync('./result.json', JSON.stringify(data, null, 2));
})();
