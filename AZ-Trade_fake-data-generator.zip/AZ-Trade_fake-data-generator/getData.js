const fetch = require('node-fetch');
const COUNTRIES = require('./data/countries.json');
const fs = require('fs');

(async () => {
  const results = COUNTRIES.map(async ({ countryCode }) => {
    try {
      const data = await fetch(`https://api-services.uat.1placedessaisons.com/uatm/v1/companyIdentifierTypes?countryCode=${countryCode}`);
      if (data.status === 200) {
        return await data.json();
      }
    } catch (e) {
      console.error(countryCode, e);
      return [];
    }
  });
  Promise.all(results).then(
    (data) => {
      const identifiers = data.reduce((acc = [], value) => {
        if (value) {
          return [...acc, ...value];
        }
        else {
          return acc;
        }
      }, []);
      fs.writeFileSync('./data/companyIdentifiers.json', JSON.stringify(identifiers), null, 2);
    });
})();
